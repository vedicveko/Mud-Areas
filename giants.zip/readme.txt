AGAINST THE GIANTS
(giants.zip, contains this file, plus steading.are, rift.are, firehall.are)
- A Rolindar Production, based on the works of Gary Gygax.

These are all vers 1.0, probably got bugs and other problems. Don't hesitate
to report them! :)

AREA #1- The Steading of the Hill Giant Chief(127k)

Preamble- The players will have heard rumors of a giant uprising somewhere,
preferably from a well-known mob in your capital city. They then can explore
and hopefully find the Steading, which can be connected in a hilly area
somewhere, moria.are works fine if you're using it, otherwise whatever you
see fit. Connx room is 29949.

AREA #2- The Glacial Rift of the Frost Giant Jarl(111k)

Preamble- Having battled, defeated and looted the hill giants, players find
out that more than a simple hill giant raid is in progress! The only way to
proceed to the next stage of the giantish purge is through manipulation of
the adamantite chain owned by Nosnra in Area #1, which is located in his
secret treasury (obj 29875 in room 29877). This room is difficult to find,
if you think it is beyond your players simply make it easier to find. Or,
you can join Area #2 in a suitable arctic environment, the connx room is
32200, and you will have to alter descs appropriately.

AREA #3- The Hall of the Fire Giant King(228k)

Preamble- The trail leads to the fire giants, and by now players should be
aware that Drow are in fact behind these giantish uprisings. An iron bar in
the Jarl's treasure chamber (obj 32226 room 32299) can be manipulated to
transport characters to 32000, the connx room of Area #3. You can also make
a physical link, joining it to a volcano or similar, adjusting descs to suit.
Here, they will face mighty challenges, including a truly awesome dragon,
and hints will be made that the fight must be taken below, to the Drow
themselves!

NOTE- To facilitate ease of multiple journeys, i have made most of Area #1
astrallable, and the first room in Areas #2 and #3 astrallable, so that
people can leave a portal character in each, should they wish, as it could
take a LONG time to return by the other means. This is assuming you do what
I did and eschew physical links to the second and third areas.

- Rolindar/Yaegar, April 1999.

Half a meg of text... WHEW! :)
