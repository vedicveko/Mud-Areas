:
cd /home/dibrova/prod/lib/
tar cvfk /home/dibrova/bk/vaults.tar vaults/* > /dev/null
cp -f /home/dibrova/bk/plr-objs.tar.old /home/dibrova/bk/plr-objs.tar.3d
cp -f /home/dibrova/bk/plr-objs.tar /home/dibrova/bk/plr-objs.tar.old
tar cvfk /home/dibrova/bk/plr-objs.tar plrobjs/* > /dev/null
cp /home/dibrova/bk/players.2 /home/dibrova/bk/players.3
cp /home/dibrova/prod/lib/etc/players /home/dibrova/bk/players.2
cp /home/dibrova/prod/lib/etc/players /home/dibrova/bk/
cd /home/dibrova/bk
tar xvf plr-objs.tar > /dev/null
chown dibrova.dibrova *
