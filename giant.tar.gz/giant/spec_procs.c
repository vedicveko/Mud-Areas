
/* Giant's Stomach -- Vedic 11/22/99 */

#define GIANT 24503

SPECIAL(giant_eats)
{
  struct char_data *giant;

  if (!CMD_IS("west"))
    return FALSE;

if (GET_SKILL(ch, SKILL_DIG)) {
  act("The stomping noise becomes deafening as you notice a huge shadow envelopyou.\n", FALSE, ch, 0, (struct char_data *)me, TO_ROOM);
  act("The stomping noise becomes deafening as you notice a huge shadow envelopyou.\n", FALSE, ch, 0, 0, TO_CHAR); 
  giant = read_mobile(GIANT, VIRTUAL);
  char_to_room(giant, IN_ROOM(ch));
  hit(giant, ch, TYPE_UNDEFINED);
return TRUE;
}
else {

  act("The stomping noise becomes deafening as you notice a huge shadow envelop you.\n", FALSE, ch, 0, (struct char_data *)me, TO_ROOM);
  act("The stomping noise becomes deafening as you notice a huge shadow envelop you.\n", FALSE, ch, 0, 0, TO_CHAR); 

act("Before you can think a giant gnarled hand grabs you and you can barely catch a glimpse of the giant's maw before the darkness comes.\r\n",
      FALSE, ch, 0, 0, TO_CHAR);

  act("Before you can think a giant hand grabs $n and swoops $m away.\r\n", FALSE, ch, 0, (struct char_data *)me, TO_ROOM);
  char_from_room(ch);
  char_to_room(ch, real_room(24504));
  GET_POS(ch) = POS_STANDING;
  act("$n falls down from above, landing with a splash.\r\n", FALSE, ch, 0, 0, TO_ROOM);
  act("You shake your head to clear it and stand up.\r\n",
      FALSE, ch, 0, 0, TO_CHAR);
  return TRUE;
}
}

#define OGDLEN2 24505

SPECIAL(giant_farts)
{

  struct char_data *leader, *ogdlen;

  if (!CMD_IS("east"))
    return FALSE;

  act("You hear a slight rumbling from behind you. You turn around just in time to see a thick /cggreen cloud/c0 rushing at you.\r\nUh Oh...\r\n/cgFFFFppPPPpppPTTTT!!!/c0\r\n", FALSE, ch, 0, 0, TO_CHAR);

  act("$n is carried away in a massive fart and disappears.\r\n", FALSE, ch, 0, (struct char_data *)me, TO_ROOM);

  if (!(leader = find_npc_by_name(ch, "Ogdlen", 6))) {
    send_to_char("You have the nagging feeling you forgot something.\r\n", ch);
  }
  else {
  //  char_from_room(leader);
    extract_char(leader);
    ogdlen = read_mobile(OGDLEN2, VIRTUAL);
    char_to_room(ogdlen, real_room(24514));
  }
  char_from_room(ch);
  char_to_room(ch, real_room(24514));
  GET_POS(ch) = POS_STANDING;
  act("$n falls down from above, landing with a thud.", FALSE, ch, 0, 0, TO_ROOM);
  act("You shake your head to clear it and stand up.\r\n",
      FALSE, ch, 0, 0, TO_CHAR);
  return TRUE;
}

#define OGDLEN1 24504

SPECIAL(ogdlen) 
{

  struct char_data *vict = (struct char_data *) me;

  if (!cmd) {
    if (GET_POS(vict) == POS_RESTING) {
      if (number(0, 1) == 0) {
	act("$n looks at you.", FALSE, ch, 0, 0,TO_ROOM);
	do_say(vict, "Hi, I seem to be lost. Will you help me out of here?", 0, 0);
	send_to_char("Type OKAY to agree.\r\n", ch);
	return TRUE;
      }
    }
  }

  if (CMD_IS("okay")) {
  
         sprintf(buf, "Ogdlen says, 'Good Deal! Let's Go!'\n");
         send_to_char(buf, ch);
	 do_stand(vict, 0, 0, 0);
         add_follower(vict, ch);
	 return TRUE;
        
  }
return FALSE;
}

SPECIAL(ogdlen2) 
{

  struct char_data *vict = (struct char_data *) me;

  if (!cmd) {
    if (number(0, 1) == 0) {
      do_say(vict, "Wow! You did it.", 0, 0);
      send_to_char("Type OKAY for a reward.\r\n", ch);
      return TRUE;
    }
  }

  if (CMD_IS("okay")) {
  
         sprintf(buf, "Ogdlen says, 'I shall now instruct you in an ancient Dwarven skill'\n");
	 strcat(buf, "Ogdlen teaches you how to digup and bury items!\r\n");
         send_to_char(buf, ch);
	 if (!(GET_SKILL(ch, SKILL_DIG))) {
	   SET_SKILL(ch, SKILL_DIG, 100); 
	   SET_SKILL(ch, SKILL_BURY, 100); 
	 }
	 send_to_char("Ogdlen waves goodbye and leaves east.\r\n", ch);
	 extract_char(vict);
	 return TRUE;
        
  }
return FALSE;
}

SPECIAL(mean_goblin)
{
  struct char_data *vict = (struct char_data *) me, *leader;
  leader = find_npc_by_name(ch, "Ogdlen", 6);

  if (cmd) {
    return FALSE;
  }

  if (FIGHTING((struct char_data *)me)) {
    switch(number(0, 10)) {
    case 0:
      do_generic_skill(vict, leader, SKILL_ROUNDHOUSE);
      break;
    case 1:
      break;
    case 2:
      break;
    case 3: case 4: case 5: case 6: case 7:
      do_generic_skill(vict, leader, SKILL_KNEE);
      break;
    default:
      break;

    }
    return TRUE;
  }
  if (!(leader = find_npc_by_name(ch, "Ogdlen", 6))) {
    return FALSE;
  }
  else {
     do_mob_bash(vict, leader);
     return TRUE;
  }
  return FALSE;
}
/* End of Giant's Stomach */

  ASSIGNROOM(24502, giant_eats);
  ASSIGNROOM(24513, giant_farts);
  ASSIGNMOB(24501, ogdlen);
  ASSIGNMOB(24505, ogdlen2);
  ASSIGNMOB(24509, mean_goblin);
